


# Preview

!["How To Create Responsive Movie Website Using HTML CSS And jQuery"](https://raw.githubusercontent.com/igcardoso/PlayFlix_beta_version.0.0.1/main/images/Screenshot_20220329-065132.png "How To Create Responsive Movie Website Using HTML CSS And jQuery")

# Social networks 

    Instagram: @playflix_plus
    YouTube: @PlayFlix Plus

# Description

    Responsive movie site, PlayFlix Beta version with no release date 

# Resource

    Boxicons: https://boxicons.com/

    Google font: https://fonts.google.com/

    Owl Carousel: https://owlcarousel2.github.io/OwlCarousel2/docs/started-welcome.html
